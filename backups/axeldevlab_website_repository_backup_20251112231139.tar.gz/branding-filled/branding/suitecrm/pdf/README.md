Put custom PDF templates here. Reference header/footer images from ./logos.
