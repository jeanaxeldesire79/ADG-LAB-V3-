# InvenioRDM Theme
Mount path: ./branding/invenio → /opt/invenio/static/theme

## Load custom CSS
- Ensure Invenio serves `/static/theme`.
- In config (example): `APP_THEME = {'css': ['/static/theme/css/custom.css']}`
- Replace `img/logo.svg`.
