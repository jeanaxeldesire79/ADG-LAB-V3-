# Docuseal Branding
Mount path: ./branding/docuseal → /app/public/branding

- Place your company logos under `logos/` and reference them in Docuseal templates.
- Example: `<img src="/branding/logos/logo.png" alt="Axel Dev Lab" />` in the template header.
